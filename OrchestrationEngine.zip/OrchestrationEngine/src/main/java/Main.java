import java.util.List;
import java.util.concurrent.CompletableFuture;

// Kiểm tra với cây 10 cấp
public class Main {
    public static void main(String[] args) throws Exception {
        OrchestrationEngine engine = new OrchestrationEngine(2);
        long startTime = System.currentTimeMillis();

        Task rootTask = TaskTreeGenerator.generateTaskTree(10, 3, "root");
        int totalTasks = countTasks(rootTask);
        System.out.println("Total tasks in tree: " + totalTasks);

        CompletableFuture<Void> execution = engine.execute(rootTask);

        new Thread(() -> {
            try {
                Thread.sleep(1000);
                Task level5Task = findTaskAtLevel(rootTask, 5);
                if (level5Task != null) {
                    System.out.println("Attempting to cancel task at level 5: " + level5Task.getTaskId());
                    engine.cancelTask(level5Task.getTaskId());
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

        execution.get();

        List<TaskResult> results = engine.getResults();
        System.out.println("\nResults (" + results.size() + " tasks):");
        for (TaskResult result : results) {
            System.out.println(result);
        }

        long duration = System.currentTimeMillis() - startTime;
        System.out.println("Total execution time: " + duration + "ms");

        engine.shutdown();
    }

    private static int countTasks(Task task) {
        if (task == null) return 0;
        int count = 1;
        for (Task subtask : task.getSubtasks()) {
            count += countTasks(subtask);
        }
        return count;
    }

    private static Task findTaskAtLevel(Task task, int targetLevel) {
        if (task == null) return null;
        if (targetLevel == 1) return task;
        for (Task subtask : task.getSubtasks()) {
            Task found = findTaskAtLevel(subtask, targetLevel - 1);
            if (found != null) return found;
        }
        return null;
    }
}
