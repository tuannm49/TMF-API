// Record TaskResult (Java 21)
record TaskResult(String taskId, String status, String result, String error) {
    @Override
    public String toString() {
        return switch (status) {
            case "SUCCESS" -> "Task %s: %s%nResult: %s".formatted(taskId, status, result);
            case "CANCELLED" -> "Task %s: %s%nCancelled".formatted(taskId, status);
            default -> "Task %s: %s%nError: %s".formatted(taskId, status, error);
        };
    }
}
