import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

// Lớp Task
class Task {
    private final String taskId;
    final Supplier<String> action;
    private final Supplier<List<Task>> subtaskSupplier;
    private volatile String status;
    private String result;
    private String error;
    private final int priority;
    private final int maxRetries;
    private int retryCount;

    public Task(String taskId, Supplier<String> action, Supplier<List<Task>> subtaskSupplier, int priority, int maxRetries) {
        this.taskId = taskId;
        this.action = action;
        this.subtaskSupplier = subtaskSupplier != null ? subtaskSupplier : () -> new ArrayList<>();
        this.status = "PENDING";
        this.priority = Math.max(1, Math.min(10, priority));
        this.maxRetries = maxRetries;
        this.retryCount = 0;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getError() {
        return error;
    }

    public void setError(String error) {
        this.error = error;
    }

    public List<Task> getSubtasks() {
        return subtaskSupplier.get();
    }

    public int getPriority() {
        return priority;
    }

    public int getMaxRetries() {
        return maxRetries;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void incrementRetryCount() {
        this.retryCount++;
    }
}
