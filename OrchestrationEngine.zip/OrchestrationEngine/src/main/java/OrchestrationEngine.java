import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;
import java.util.logging.Logger;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

// Engine orchestration với virtual threads
class OrchestrationEngine {
    private final ExecutorService executor;
    private final PriorityBlockingQueue<Runnable> taskQueue;
    private final ConcurrentLinkedQueue<TaskResult> resultQueue;
    private final Map<String, CompletableFuture<Void>> taskFutures;
    private final Logger logger;
    private final long timeoutSeconds;

    public OrchestrationEngine(long timeoutSeconds) {
        // Sử dụng virtual threads
        this.executor = Executors.newVirtualThreadPerTaskExecutor();
//        this.executor = Executors.newSingleThreadExecutor();
                this.taskQueue = new PriorityBlockingQueue<>(10, (r1, r2) -> {
            if (r1 instanceof TaskWrapper tw1 && r2 instanceof TaskWrapper tw2) {
                return tw2.task().getPriority() - tw1.task().getPriority();
            }
            return 0;
        });
        this.resultQueue = new ConcurrentLinkedQueue<>();
        this.taskFutures = new ConcurrentHashMap<>();
        this.logger = Logger.getLogger(OrchestrationEngine.class.getName());
        this.timeoutSeconds = timeoutSeconds;
    }

    private record TaskWrapper(Task task, OrchestrationEngine engine) implements Runnable {
        @Override
        public void run() {
            engine.processTask(task);
        }
    }

    public void registerTask(Task task) {
        logger.info("Registered task: %s with priority: %d".formatted(task.getTaskId(), task.getPriority()));
    }

    private void processTask(Task task) {
        long startTime = System.currentTimeMillis();
        logger.info("Starting task: %s".formatted(task.getTaskId()));

        try {
            task.setStatus("RUNNING");

            CompletableFuture<String> actionFuture = CompletableFuture.supplyAsync(task.action, executor);
            String result = actionFuture.orTimeout(timeoutSeconds, TimeUnit.SECONDS).get();
            task.setResult(result);

            List<Task> subtasks = task.getSubtasks();
            subtasks.forEach(this::registerTask);

            List<CompletableFuture<Void>> subtaskFutures = new ArrayList<>();
            for (Task subtask : subtasks) {
                CompletableFuture<Void> subtaskFuture = CompletableFuture.runAsync(
                        new TaskWrapper(subtask, this), executor);
                taskFutures.put(subtask.getTaskId(), subtaskFuture);
                subtaskFutures.add(subtaskFuture);
            }

            CompletableFuture.allOf(subtaskFutures.toArray(new CompletableFuture[0])).join();

            boolean allSubtasksSuccess = subtasks.stream().allMatch(subtask -> "COMPLETED".equals(subtask.getStatus()));

            if (allSubtasksSuccess) {
                task.setStatus("COMPLETED");
                resultQueue.add(new TaskResult(task.getTaskId(), "SUCCESS", task.getResult(), null));
                logger.info("Task %s completed successfully in %dms"
                        .formatted(task.getTaskId(), System.currentTimeMillis() - startTime));
            } else {
                task.setStatus("FAILED");
                resultQueue.add(new TaskResult(task.getTaskId(), "FAILED", null, "One or more subtasks failed"));
                logger.warning("Task %s failed due to subtask failure".formatted(task.getTaskId()));
            }
        } catch (Exception e) {
            if (e instanceof CancellationException) {
                task.setStatus("CANCELLED");
                resultQueue.add(new TaskResult(task.getTaskId(), "CANCELLED", null, "Task was cancelled"));
                logger.info("Task %s was cancelled".formatted(task.getTaskId()));
            } else {
                task.incrementRetryCount();
                if (task.getRetryCount() < task.getMaxRetries()) {
                    logger.warning("Retrying task %s (Attempt %d/%d)"
                            .formatted(task.getTaskId(), task.getRetryCount() + 1, task.getMaxRetries()));
                    CompletableFuture<Void> retryFuture = CompletableFuture.runAsync(
                            new TaskWrapper(task, this), executor);
                    taskFutures.put(task.getTaskId(), retryFuture);
                    return;
                } else {
                    task.setStatus("FAILED");
                    task.setError(e.getMessage());
                    resultQueue.add(new TaskResult(task.getTaskId(), "FAILED", null, e.getMessage()));
                    logger.severe("Task %s failed after %d retries: %s"
                            .formatted(task.getTaskId(), task.getMaxRetries(), e.getMessage()));
                }
            }
        } finally {
            taskFutures.remove(task.getTaskId());
        }
    }

    public CompletableFuture<Void> execute(Task rootTask) {
        registerTask(rootTask);
        CompletableFuture<Void> future = CompletableFuture.runAsync(
                new TaskWrapper(rootTask, this), executor);
        taskFutures.put(rootTask.getTaskId(), future);
        return future;
    }

    public boolean cancelTask(String taskId) {
        CompletableFuture<Void> future = taskFutures.get(taskId);
        if (future == null) {
            logger.warning("Cannot cancel task %s: Task not found or already completed".formatted(taskId));
            return false;
        }

        boolean cancelled = future.cancel(true);
        if (cancelled) {
            logger.info("Cancelled task: %s".formatted(taskId));
            taskFutures.keySet().stream()
                    .filter(id -> id.startsWith(taskId + "_") || taskFutures.get(id).equals(future))
                    .forEach(subTaskId -> {
                        CompletableFuture<Void> subFuture = taskFutures.get(subTaskId);
                        if (subFuture != null) {
                            subFuture.cancel(true);
                            logger.info("Cancelled subtask: %s".formatted(subTaskId));
                        }
                    });
        }
        return cancelled;
    }

    public List<TaskResult> getResults() {
        List<TaskResult> results = new ArrayList<>();
        while (!resultQueue.isEmpty()) {
            results.add(resultQueue.poll());
        }
        return results;
    }

    public void shutdown() {
        executor.close(); // Java 21: AutoCloseable ExecutorService
        logger.info("Orchestration engine shutdown");
    }
}

