import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.function.Supplier;

// Lớp sinh cây task
class TaskTreeGenerator {
    private static final Random random = new Random();

    public static Task generateTaskTree(int depth, int maxSubtasks, String parentId) {
        if (depth <= 0) return null;

        String taskId = parentId + "_" + UUID.randomUUID().toString().substring(0, 8);
        int priority = random.nextInt(10) + 1;
        int maxRetries = 2;

        Supplier<List<Task>> subtaskSupplier = () -> {
            List<Task> subtasks = new ArrayList<>();
            int numSubtasks = random.nextInt(maxSubtasks + 1);
            for (int i = 0; i < numSubtasks && depth > 1; i++) {
                Task subtask = generateTaskTree(depth - 1, maxSubtasks, taskId);
                if (subtask != null) subtasks.add(subtask);
            }
            return subtasks;
        };

        return new Task(taskId, () -> sampleAction(taskId), subtaskSupplier, priority, maxRetries);
    }

    private static String sampleAction(String taskName) {
        try {
            Thread.sleep(500);
            if (random.nextDouble() < 0.1) {
                throw new RuntimeException("Random failure in " + taskName);
            }
            return "Result of " + taskName;
        } catch (InterruptedException e) {
            throw new RuntimeException("Interrupted: " + taskName);
        }
    }
}
